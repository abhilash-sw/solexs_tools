CALDB_BASE_DIR = '/home/abhilash/abhilash/SOLEXS/solexs_codes/solexs_tools/CALDB/aditya-l1/solexs/data/cpf'
