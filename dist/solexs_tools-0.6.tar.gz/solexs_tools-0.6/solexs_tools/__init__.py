#####################################################
# @Author: SoLEXSPOC
# @Date:   2024-11-17 09:27:23 pm
# @email: sarwade@ursc.gov.in
# @File Name: __init__.py
# @Project: solexs_tools
#
# @Last Modified time: 2024-12-19 01:33:12 pm
#####################################################

__version__ = 0.6
